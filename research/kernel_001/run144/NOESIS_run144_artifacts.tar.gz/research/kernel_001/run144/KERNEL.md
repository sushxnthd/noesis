# NOESIS Kernel 001 after Run 144

1. **Precise question:** Can a task-coupled reachable-state proof obligation, rather than finite trajectory consistency, identify learned unbounded counting across non-axis-aligned trained recurrent representations?
2. **Primary frontier:** El-Naggar et al., ICGI 2023 (single-cell CICs); EACL SRW 2023 (linear counting); classical inductive invariants and simulation relations. Novelty unestablished.
3. **One exact success criterion:** At least one ordinarily gradient-trained, non-axis-aligned 3-state model satisfies an independently checked all-alphabet unbounded task-output certificate without output calibration or task-specific weight editing.
4. **Strongest competing explanation:** Isolated hidden counting coordinates, precision rounding, post-hoc gain correction, and finite-horizon cap spoof.
5. **Cheapest decisive falsification:** Check all-alphabet reachable-state and readout obligations exactly on existing 3-state checkpoints, and adversarially search for an activation-boundary violation before any new training.
6. **Publishable threshold:** Primary-literature novelty plus independent proof, strong spoofs, frozen unseen architectures, and causal learning-transition evidence.
7. **Learning relevance threshold:** A certificate must hold on an ordinary gradient-trained checkpoint and predict unseen task conditions, not merely a hand-constructed machine.
8. **Kill condition:** After three further substantive attempts without a non-axis-aligned trained-model certificate or a useful new falsification that changes evaluation, retire Kernel 001 and activate one backup.

**Only active kernel:** 001. Backups (inactive): prospective cross-architecture predictor; intervention on task-state representation.
