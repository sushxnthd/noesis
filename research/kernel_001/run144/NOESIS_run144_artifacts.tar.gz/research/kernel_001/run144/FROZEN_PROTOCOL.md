# NOESIS Kernel 001 — Run 144 frozen protocol (2026-10-14)

**Precise question:** Does an observable task-state-quotient defect add predictive value beyond training loss for length-256 generalization of ordinary gradient-trained 3-state ReLU RNNs?

**Literature frontier:** El-Naggar et al., ICGI 2023 (https://proceedings.mlr.press/v217/el-naggar23a.html), exact single-cell counter indicator conditions and difficulty of gradient acquisition; EACL SRW 2023 (https://aclanthology.org/2023.eacl-srw.15/), linear recurrent counting failures. Our quotient test is not claimed as novel theory.

**Source and split:** Unmodified archived Run 138 3-state checkpoints seeds 200..207, both float32 and float64, ordinary gradient training on all length-six ternary sequences. Calibrate thresholds ONLY on float32 seeds 200..203; hold out seed IDs 204..207 in both precisions. Paired precisions are not independent samples. Do not retrain or choose seeds after inspection.

**Diagnostic:** For reflected counter starting at zero, prefixes P={empty,+-,0,-,+-+-,+0-} all have task state zero. Continuations C={empty,++++,+-+-,0000}. For each continuation c compute all outputs y(p+c). Define D=max_c(max_p y(p+c)-min_p y(p+c)). Exact coefficients mean each archived binary float is interpreted as an exact rational; main calculation is float64 approximation, independent checker uses Fraction.

**One scalar success criterion:** On held-out seed IDs 204..207, D-threshold must produce strictly MORE correct length-256 pass/fail classifications than an MSE threshold calibrated on the same development seeds. Lower is predicted pass. Calibration threshold is geometric mean of maximum development-PASS score and minimum development-FAIL score, if strictly separated; otherwise calibration fails. For numerical zeros, use next positive representable value as floor. Holdout float64 is robustness check.

**Competing explanation:** D is merely a surrogate for training loss and admits a bounded-counter spoof.

**Cheapest decisive falsification:** Compare D vs train loss on heldout seeds; independently recompute exact rational D; run cap M=12 spoof. Cap spoof must match all tested words (max length 8) yet fail on +^13.

**Publishable threshold:** Prospective cross-architecture advantage over training loss plus a spoof-resistant, mechanism-derived prediction and independent verification. This run cannot alone meet it.

**Learning relevance threshold:** Every primary classification is on an ordinary gradient-trained 3-state network; constructed cap is only a negative control.

**Kill condition:** Reject quotient defect as a sufficient acquisition certificate if bounded cap passes D=0, and reject it as a useful incremental predictor if it does not outperform training loss on heldout seeds.

**Only active kernel:** 001. Backups: invariant reachable-state simulation; prospective cross-architecture test. Zero user spend; local CPU only; no user laptop.
