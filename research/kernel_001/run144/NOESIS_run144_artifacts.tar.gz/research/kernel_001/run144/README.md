# NOESIS Kernel 001 / Run 144 — negative quotient diagnostic

Run `python run144.py`, `python independent_check.py`, `python -m unittest -v test_run144.py` from this directory after ensuring `research/kernel_001/run138/RAW_OUTCOMES.json` exists. `run144.py` needs numpy; independent checker uses Python standard library Fraction. All checkpoints were trained in Run 138, not this run. Run 144 does not claim a field-level breakthrough. See FROZEN_PROTOCOL.md for registered criterion and CLAIM.md for supported result.
