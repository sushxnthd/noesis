"""Frozen short task-state-quotient diagnostic on archived ordinary-gradient checkpoints.

Usage: python run144.py; no training or model selection is performed.
"""
from __future__ import annotations
import hashlib,json,math
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
SOURCE=HERE/'SOURCE_CHECKPOINTS.json'
P=((),(0,1),(2,),(1,),(0,1,0,1),(0,2,1))
C=((),(0,0,0,0),(0,1,0,1),(2,2,2,2))

def score(params):
    A=np.asarray(params['A'],dtype=np.float64)
    E=np.asarray(params['E'],dtype=np.float64)
    w=np.asarray(params['w'],dtype=np.float64)
    def y(word):
        h=np.zeros(len(w),dtype=np.float64)
        for t in word:h=np.maximum(0,A@h+E[t])
        return float(w@h)
    ranges=[]
    for c in C:
        ys=[y(p+c) for p in P]
        ranges.append(max(ys)-min(ys))
    return max(ranges)

def threshold(rows,key):
    passed=[r[key] for r in rows if r['pass256']]
    failed=[r[key] for r in rows if not r['pass256']]
    if not passed or not failed:return None
    lo=max(passed);hi=min(failed)
    if lo>=hi:return None
    return math.sqrt(max(lo,np.nextafter(0.,1))*hi)

def cap(word,M=12):
    h=0
    for t in word:
        u=(1,-1,0)[t]
        h=max(0,h+u)-max(0,h+u-M)
    return h

def main():
    src=SOURCE.read_bytes();allrows=json.loads(src)
    rows=[]
    for r in allrows:
        if r['dimension']!=3:continue
        item={k:r[k] for k in ('seed','dimension','dtype','train_mse','pass256','plus256_abs_error','return256_abs_error')}
        item['quotient_defect']=score(r['parameters'])
        rows.append(item)
    dev=[r for r in rows if r['seed'] in (200,201,202,203) and r['dtype']=='torch.float32']
    hold=[r for r in rows if r['seed'] in (204,205,206,207)]
    assert len(dev)==4 and len(hold)==8 and len(rows)==16
    thresholds={k:threshold(dev,k) for k in ('quotient_defect','train_mse')}
    assert all(t is not None for t in thresholds.values())
    for r in rows:
        for key,t in thresholds.items():
            r[key+'_prediction']=r[key]<t
            r[key+'_correct']=r[key+'_prediction']==r['pass256']
    metrics={key:{'development_correct':sum(r[key+'_correct'] for r in dev),
                  'holdout_float32_correct':sum(r[key+'_correct'] for r in hold if r['dtype']=='torch.float32'),
                  'holdout_float64_correct':sum(r[key+'_correct'] for r in hold if r['dtype']=='torch.float64')}
             for key in thresholds}
    spoof={
      'M':12,
      'D':max(max(cap(p+c) for p in P)-min(cap(p+c) for p in P) for c in C),
      'first_fail_plus_word':13,
      'at_length_12':cap((0,)*12),
      'at_length_13':cap((0,)*13),
    }
    assert spoof=={'M':12,'D':0,'first_fail_plus_word':13,'at_length_12':12,'at_length_13':12}
    result={'protocol_sha256':hashlib.sha256((HERE/'FROZEN_PROTOCOL.md').read_bytes()).hexdigest(),
            'source_sha256':hashlib.sha256(src).hexdigest(),
            'development_seed_ids':[200,201,202,203],
            'heldout_seed_ids':[204,205,206,207],
            'thresholds':thresholds,'metrics':metrics,'spoof':spoof,
            'rows':rows,
            'incremental_predictive_value':metrics['quotient_defect']['holdout_float32_correct']-metrics['train_mse']['holdout_float32_correct'],
            'sufficient_certificate_falsified':spoof['D']==0 and spoof['at_length_13']!=13}
    (HERE/'OUTCOMES.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:result[k] for k in ('thresholds','metrics','spoof','incremental_predictive_value','sufficient_certificate_falsified')},indent=2))
    return result
if __name__=='__main__':main()
