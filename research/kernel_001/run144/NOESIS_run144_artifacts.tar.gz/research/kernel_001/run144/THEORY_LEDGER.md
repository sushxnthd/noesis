# THEORY ledger — Run 144

A finite quotient-output defect D can be exactly zero for a recurrent model that fails unbounded counting. The cap-12 recurrence h' = ReLU(h+u)-ReLU(h+u-12) agrees with the reflected counter on every word of length at most 12; the fixed quotient test observes words of length at most 8 and gives D=0. On +^13 the model outputs 12 rather than 13. Thus this particular finite quotient consistency test is **falsified as a sufficient certificate**. This is a classical finite-horizon spoof and not a new theorem. It does not falsify infinite-context behavioral equivalence.

For archived 3-state checkpoints, independent exact-rational evaluation of stored binary float weights agreed with approximate float64 D to within 1e-11 absolute on all 16 paired-precision records. Exact nonzero residuals alone do not prove an unbounded failure horizon; no such claim is made.
