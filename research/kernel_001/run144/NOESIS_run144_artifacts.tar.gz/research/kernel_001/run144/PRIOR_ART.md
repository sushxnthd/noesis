# Primary-literature collision

- El-Naggar, Ryzhikov, Daviaud, Madhyastha, Weyde (2023), *Formal and Empirical Studies of Counting Behaviour in ReLU RNNs*, ICGI, https://proceedings.mlr.press/v217/el-naggar23a.html — exact single-cell conditions and standard-training failure.
- El-Naggar, Madhyastha, Weyde (2023), *Theoretical Conditions and Empirical Failure of Bracket Counting on Long Sequences with Linear Recurrent Networks*, EACL SRW, https://aclanthology.org/2023.eacl-srw.15/ — exact linear-cell conditions and extrapolation failure.

Finite-horizon indistinguishability and quotient/bisimulation concepts are classical. No new priority claim.
