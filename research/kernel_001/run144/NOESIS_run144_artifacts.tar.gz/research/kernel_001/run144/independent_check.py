"""Independent exact-rational nonlinear evaluator; no numpy and no run144.score import."""
from fractions import Fraction as Q
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent
P=((),(0,1),(2,),(1,),(0,1,0,1),(0,2,1))
C=((),(0,0,0,0),(0,1,0,1),(2,2,2,2))

def eval_exact(params,word):
    A=[[Q(v) for v in row] for row in params['A']]
    E=[[Q(v) for v in row] for row in params['E']]
    w=[Q(v) for v in params['w']]
    h=[Q(0) for _ in w]
    for token in word:
        h=[max(Q(0),sum(A[i][j]*h[j] for j in range(len(w)))+E[token][i]) for i in range(len(w))]
    return sum((a*b for a,b in zip(w,h)),Q(0))

def exact_defect(p):
    return max(max(eval_exact(p,prefix+suffix) for prefix in P)-min(eval_exact(p,prefix+suffix) for prefix in P) for suffix in C)

def main():
    source=json.loads((HERE/'SOURCE_CHECKPOINTS.json').read_text())
    results=json.loads((HERE/'OUTCOMES.json').read_text())
    rows={(r['seed'],r['dtype']):r for r in results['rows']}
    compared=[]
    for r in source:
        if r['dimension']!=3:continue
        score=exact_defect(r['parameters'])
        recorded=rows[r['seed'],r['dtype']]['quotient_defect']
        assert abs(float(score)-recorded)<1e-11*max(1.,abs(float(score)))
        compared.append({'seed':r['seed'],'dtype':r['dtype'],
                         'exact_num':str(score.numerator),'exact_den':str(score.denominator),
                         'float64':float(score)})
    assert len(compared)==16
    # Independent bounded counter, not invoking run144.cap.
    for prefix in P:
        for suffix in C:
            count=0;target=0
            for t in prefix+suffix:
                delta=(1,-1,0)[t]
                count=min(12,max(0,count+delta))
                target=max(0,target+delta)
            assert count==target
    count=0
    for _ in range(13):count=min(12,count+1)
    assert count==12
    (HERE/'INDEPENDENT_OUTCOMES.json').write_text(json.dumps({'exact_models_verified':len(compared),'models':compared,'spoof_verified':True},indent=2)+'\n')
    print('PASS: exact rational quotient scores agree on 16 archived gradient-trained 3-state checkpoints; cap spoof verified')
if __name__=='__main__':main()
