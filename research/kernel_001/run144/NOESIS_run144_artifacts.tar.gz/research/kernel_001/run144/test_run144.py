import unittest
from pathlib import Path
import importlib.util
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('run144',ROOT/'run144.py')
run=importlib.util.module_from_spec(spec);spec.loader.exec_module(run)
class TestRun144(unittest.TestCase):
 def test_all_task_equivalent_prefixes(self):
  for p in run.P:
   q=0
   for t in p:q=max(0,q+(1,-1,0)[t])
   self.assertEqual(q,0)
 def test_cap_is_exact_on_observed_words(self):
  for p in run.P:
   for c in run.C:
    q=0
    for t in p+c:q=max(0,q+(1,-1,0)[t])
    self.assertEqual(run.cap(p+c),q)
 def test_cap_fails_after_observed_horizon(self):
  self.assertEqual(run.cap((0,)*12),12)
  self.assertEqual(run.cap((0,)*13),12)
 def test_run_reproduces(self):
  out=run.main()
  self.assertEqual(out['metrics']['quotient_defect']['holdout_float32_correct'],out['metrics']['train_mse']['holdout_float32_correct'])
if __name__=='__main__':unittest.main()
